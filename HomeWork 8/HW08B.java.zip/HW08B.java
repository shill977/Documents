/**
 * Fall 2018 
 * CIS 351
 * Part of Homework 8
 * Name: Suzanne Hill
 * Email: shill100@syr.edu
 */
public class HW08B {
  
  /* Main function */
  
  public static void main (String [] argv){
  task1();
  task2();
  }
  public static void task1(){
    System.out.println("HW8B, Task 1\n");
    // Follow the instructions given in Homework description,
    // write the code below
    
    System.out.println("End of Task 1\n");     
  }
  public static void task2(){
    System.out.println("HW8B, Task 2\n");
    // Follow the instructions given in Homework description,
    // write the code below
    
    System.out.println("End of Task 2\n");
  }
}